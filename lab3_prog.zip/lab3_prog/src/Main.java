import enums.ActionsWithMoneyEnum;
import interfaces.ActionsWithPeopleInterface;
import usual_classes.Money;
import usual_classes.RichPerson;
import usual_classes.Society;
import usual_classes.Somebody;


public class Main {
    public static void main(String[] args){

        Society society = new Society();
        Somebody somebody = new Somebody();
        Money money = new Money();

        RichPerson others = new RichPerson("Другие");
        money.actionWithPeople(others, money);
        others.actionWithMoney(money, somebody, society);

        RichPerson scuperfild = new RichPerson();
        money.actionWithPeople(scuperfild, money);
        scuperfild.actionWithMoney(money, somebody, society);
        somebody.isItStrange(scuperfild, society);
        somebody.think(scuperfild, society);
        somebody.actionWithPeople(scuperfild, money);
    }
}
