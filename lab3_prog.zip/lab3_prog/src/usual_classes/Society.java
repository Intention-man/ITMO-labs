package usual_classes;

import abstract_class.PeopleAbstract;

import java.util.Objects;

public class Society extends PeopleAbstract {

    private String mainValue;
    private String name;

    public Society(){
        this.setName("алчное");
        this.setMainValue("деньги");
    }

    public Society(String name){
        this.setName(name);
        this.setMainValue("счастливое будущее");
    }

    public String getMainValue() {
        return this.mainValue;
    }

    public void setMainValue(String mainValue) {
        this.mainValue = mainValue;
    }

    public void continueStory(String name){
        System.out.println("Поскольку в обществе главной ценностью счита(е/ю)тся " + this.getMainValue() + " [потому что общество " + name + "].");
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Society society = (Society) o;
        return this.getMainValue().equals(society.getMainValue()) && this.getName().equals(society.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(mainValue, name);
    }

    public String toString() {
        return name;
    }
}