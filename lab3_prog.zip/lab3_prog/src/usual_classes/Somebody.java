package usual_classes;

import abstract_class.PeopleAbstract;
import enums.ActionsWithPeopleEnum;
import interfaces.ActionsWithPeopleInterface;

import java.util.ArrayList;
import java.util.Objects;

public class Somebody extends PeopleAbstract implements ActionsWithPeopleInterface{
    ArrayList<ActionsWithPeopleEnum> awpe = new ArrayList<>();

    public Somebody() {
        this.setName("Окружающие");}

    public void actionWithPeople(RichPerson rich, Money money) {
        if (rich.isObey(money.getName())) {
            this.addAction(ActionsWithPeopleEnum.TAKETOADOCTOR);
            this.addAction(ActionsWithPeopleEnum.TREATASINSANE);
            this.writeActionOut();
        }
    }

    public void isItStrange(RichPerson rich, Society society){
        continueStory(rich.getName());
        if (Objects.equals(society.getMainValue(), "деньги")) {
            System.out.println(" естественным.");
        } else {
            System.out.println(" странным и неадекватным.");
        }
        society.continueStory(society.getName());
    }

    public void think(RichPerson rich, Society society){
        if (Objects.equals(society.getMainValue(), "деньги")){
            System.out.print("И " + this.getName() + " в голову не приходило, что ");
        } else {System.out.print("И " + this.getName() + "всерьез задумывались о том, чтобы ");}
        System.out.print("господина " + rich.getName() + " давно следовало ");
    }

    public ArrayList<ActionsWithPeopleEnum> getActions() {
        return this.awpe;
    }

    public void addAction(ActionsWithPeopleEnum action) {
        this.awpe.add(action);
    }
    public void writeActionOut() {
        StringBuilder awpe_str = new StringBuilder();
        for (ActionsWithPeopleEnum action : this.getActions()) {
            awpe_str.append(action.getStr()).append(" и ");
        }
        System.out.println(awpe_str.substring(0, awpe_str.length() - 2) + "!");
    }
    @Override
    public void continueStory(String name) {
        System.out.print("Окружающие считали поведение богача " + name);

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Somebody somebody = (Somebody) o;
        return Objects.equals(this.getName(), somebody.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getName());
    }

    public String toString() {
        return this.getName();
    }
}
