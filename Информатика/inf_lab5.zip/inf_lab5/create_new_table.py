import csv

with open('SPFB.RTS-12.18_180901_181231.csv', newline='') as csvread:
    with open('number19.csv', 'w', newline='') as csvwrite:
        reader = csv.DictReader(csvread, delimiter=",")
        c = 0
        for row in reader:
            if c == 0:
                fieldnames = row.keys()
                writer = csv.DictWriter(csvwrite, fieldnames=fieldnames)
                writer.writeheader()
                c = 1
            if row['<DATE>'].split("/")[0] == "19":
                writer.writerow(row)
