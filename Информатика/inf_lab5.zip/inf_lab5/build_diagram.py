import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

df = pd.read_csv('number19.csv')
df.drop(["<TICKER>", "<PER>", "<DATE>", "<TIME>", "<VOL>"], axis=1, inplace=True)
print(df)
mpl.style.use(['ggplot'])

selection = df
selection.plot(kind='box', figsize=(8, 6))
plt.title('Futures rate')
plt.ylabel('VALUE')
plt.show()