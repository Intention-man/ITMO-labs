f = len("Агей")
i = len("Михаил")
o = len("Александрович")

print((f*i) % 13)
print((o*i) % 13)
print((f*o) % 13)
