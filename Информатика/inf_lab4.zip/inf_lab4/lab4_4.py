# coding: utf-8

import json
import csv


with open('schedule.json', "r", encoding="utf-8") as json_file:
    data = json.load(json_file)
    print(data)

columns = set(i for number in data for i in data[number])
print(columns)
data_file = open('lab4_4.csv', 'w', encoding="utf-8")
csv_writer = csv.DictWriter(data_file, fieldnames=columns)

csv_writer.writeheader()
for number in data:
    csv_writer.writerow(data[number])

data_file.close()