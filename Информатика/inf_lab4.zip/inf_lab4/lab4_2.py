# coding: utf-8

import json


def second():
    with open("schedule.json", "r", encoding="utf-8") as ex:
        s = json.load(ex)
        with open("lab4_2.xml", "w", encoding="utf-8") as im:
            im.write('<?xml version="1.0" ?>')
            c = ['<root>']
            for number in s:
                c.append(f'<{number}>')
                for param in s[number]:
                    c.append(f'<{param}>{s[number][param]}</{param}>')
                c.append(f'</{number}>')
            c.append('</root>')
            for string in c:
                im.write("\n")
                im.write(string)