# coding: utf-8

import json as JS
import xml.etree.ElementTree as ET


def first():
    with open("schedule.json", "r", encoding="utf-8") as json_file:
        data = JS.load(json_file)

        root = ET.Element("root")

        for number in data:
            a = ET.SubElement(root, number)
            for param in data[number]:
                ET.SubElement(a, param).text = data[number][param]
        """first = ET.SubElement(root, "first")
    
        ET.SubElement(first, "day").text = data["first"]["day"]
        ET.SubElement(first, "time").text = data["first"]["time"]
        ET.SubElement(first, "room").text = data["first"]["room"]"""

        tree = ET.ElementTree(root)
        ET.indent(tree, '  ')
        tree.write("lab4_1.xml", encoding="utf-8", xml_declaration=True)