# coding: utf-8

import json


def zero():
    with open("schedule.json", "r", encoding="utf-8") as ex:
        s = json.load(ex)
        with open("lab4_0.xml", "w", encoding="utf-8") as im:
            im.write('<?xml version="1.0" ?>')
            c = ['<root>']
            for number in s:
                a = "<" + number + ">"
                c.append(a)
                for param in s[number]:
                    a = "<" + param + ">" + s[number][param] + "</" + param + ">"
                    c.append(a)
                a = "</" + number + ">"
                c.append(a)
            c.append('</root>')
            for string in c:
                im.write("\n")
                im.write(string)


zero()