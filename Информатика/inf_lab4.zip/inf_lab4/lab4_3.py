import time

from lab4_0 import zero
from lab4_1 import first
from lab4_2 import second


start0 = time.time()
for _ in range(100):
    zero()
end0 = time.time()

start1 = time.time()
for _ in range(100):
    first()
end1 = time.time()

start2 = time.time()
for _ in range(100):
    second()
end2 = time.time()

print("Нулевая программа выполняется 100 раз за", (end0 - start0) * 1000, "миллисекунд")
print("Первая программа выполняется 100 раз за", (end1 - start1) * 1000, "миллисекунд")
print("Вторая программа выполняется 100 раз за", (end2 - start2) * 1000, "миллисекунд")