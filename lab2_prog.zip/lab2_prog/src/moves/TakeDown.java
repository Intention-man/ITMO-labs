package moves;

import ru.ifmo.se.pokemon.*;

public class TakeDown extends PhysicalMove {
    public TakeDown() {
        super(Type.NORMAL, 90, 85);
    }

    @Override
    public void applySelfDamage(Pokemon p, double damage) {
        p.setMod(Stat.HP, -1 * (int) Math.round(damage / 4));
    }

    @Override
    protected String describe() {
        return "бьет!...немного отхватывая в ответ(";
    }
}
