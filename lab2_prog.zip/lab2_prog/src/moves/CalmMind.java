package moves;

import ru.ifmo.se.pokemon.*;

public class CalmMind extends StatusMove {
    public CalmMind() {
        super(Type.PSYCHIC, 0, 100);
    }

    private boolean x;

    @Override
    public void applySelfEffects(Pokemon p) {
        if (p.getStat(Stat.SPECIAL_ATTACK) < 6)
    {p.setMod(Stat.SPECIAL_ATTACK, +1);}
        if (p.getStat(Stat.SPECIAL_DEFENSE) < 6)
        {p.setMod(Stat.SPECIAL_DEFENSE, +1);}
    }

    @Override
    protected String describe() {
        return "прокачивает свои спец способности!";
    }
}
