package moves;

import ru.ifmo.se.pokemon.*;

public class Venoshock extends SpecialMove{

    public Venoshock() {

        super(Type.POISON, 65, 100);
    }
    private boolean x;
    @Override
    public void applyOppEffects(Pokemon p) {
        Status cond = p.getCondition();
        if (cond.equals(Status.POISON)) {
            x = true;}
    }

    @Override
    public void applySelfEffects(Pokemon p) {
        if (x) {
            Effect e = new Effect().turns(1).stat(Stat.ATTACK, +2);
            p.addEffect(e);
        }
    }
    @Override
    protected String describe() {
        if (x) return "наносит урон... и еще раз на бис!";
        else return "наносит урон";
    }
}

