package moves;

import ru.ifmo.se.pokemon.*;

public class ThunderWave extends StatusMove {
    public ThunderWave() {
        super(Type.ELECTRIC, 0, 90);
    }

    private boolean x = true;
    private boolean y = false;

    @Override
    public void applyOppEffects(Pokemon p) {

        if (p.hasType(Type.valueOf("ELECTRIC"))) {
            x = true;
        }
        if (!x) {
            Effect.paralyze(p);
            p.setMod(Stat.SPEED, -2);
            if (Math.random() <= 0.25) {
                y = true;
                p.setMod(Stat.ACCURACY, -6);
            }
        }
    }

    @Override
    protected String describe() {
        if (x && y) return "наносит урон, парализует и блокирует атаку!";
        else if (x) return "наносит урон и парализует!";
        else return "наносит урон";
    }
}
