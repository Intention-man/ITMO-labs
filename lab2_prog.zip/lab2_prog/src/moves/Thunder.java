package moves;

import ru.ifmo.se.pokemon.*;

public class Thunder extends SpecialMove {
    public Thunder() {

        super(Type.ELECTRIC, 110, 70);
    }

    private boolean x;

    @Override
    public void applyOppEffects(Pokemon p) {
        if (Math.random() <= 0.3) {

            if (p.hasType(Type.valueOf("ELECTRIC"))) {
                x = true;
            }
            if (!x) {
                Effect.paralyze(p);
            }
        }
    }


    @Override
    protected String describe() {
        if (x) return "жоска парализует!";
        else return "наносит урон";
    }
}
