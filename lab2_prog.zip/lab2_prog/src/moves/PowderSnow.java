package moves;

import ru.ifmo.se.pokemon.*;

public class PowderSnow extends SpecialMove {
    public PowderSnow() {
        super(Type.ICE, 40, 100);
    }

    private boolean x;

    @Override
    public void applyOppEffects(Pokemon p) {
        if (Math.random() <= 0.1) {
            if (p.hasType(Type.valueOf("ICE"))) {
                x = true;
            }
            if (!x) {
                Effect.freeze(p);
            }
        }
    }

    @Override
    protected String describe() {
        if (x) return "наносит урон";
        else return "наносит урон и замораживает!";
    }
}
