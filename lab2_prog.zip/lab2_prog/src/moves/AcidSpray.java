package moves;

import ru.ifmo.se.pokemon.*;


public class AcidSpray extends SpecialMove {
    public AcidSpray() {

        super(Type.POISON, 40, 100);
    }

    private boolean x;

    @Override
    public void applyOppEffects(Pokemon p) {
        p.setMod(Stat.SPECIAL_DEFENSE, -2);
    }

    @Override
    protected String describe() {
        return "наносит урон... и ухудшает спец защиту!";
    }
}
