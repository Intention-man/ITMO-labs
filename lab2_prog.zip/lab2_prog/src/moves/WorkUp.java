package moves;

import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Stat;
import ru.ifmo.se.pokemon.StatusMove;
import ru.ifmo.se.pokemon.Type;

public class WorkUp extends StatusMove {
    public WorkUp() {
        super(Type.NORMAL, 0, 100);
    }

    private boolean x;

    @Override
    public void applySelfEffects(Pokemon p) {
        if (p.getStat(Stat.SPECIAL_ATTACK) < 6)
        {p.setMod(Stat.SPECIAL_ATTACK, +1);}
        if (p.getStat(Stat.ATTACK) < 6)
        {p.setMod(Stat.ATTACK, +1);}
    }

    @Override
    protected String describe() {
        return "прокачивает свои атакующие способности!";
    }
}
