package pokemons;

import moves.AcidSpray;
import moves.DoubleTeam;
import moves.Psychic;
import moves.Venoshock;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;


public class Buzzwole extends Pokemon{
    public Buzzwole(String name, int level) {
        super(name, level);
        setType(Type.BUG, Type.FIGHTING);
        setStats(107, 139, 139, 53, 53, 79);
        setMove(new Venoshock(), new Psychic(), new DoubleTeam(), new AcidSpray());
    }
}
