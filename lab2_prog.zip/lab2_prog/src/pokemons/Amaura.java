package pokemons;


import moves.CalmMind;
import moves.PowderSnow;
import moves.TakeDown;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public class Amaura extends Pokemon {
    {
        setType(Type.ROCK, Type.ICE);
        setStats(77, 59, 50, 67, 63, 46);
        setMove(new TakeDown(), new PowderSnow(), new CalmMind());
    }
    public Amaura(String name, int level) {
        super(name, level);
    }

    public Amaura(String name) {
        this(name, 4);
    }
}
