package main;

import pokemons.*;
import ru.ifmo.se.pokemon.*;


public class Main {
    public static void main(String[] args) {
        Battle b = new Battle();
//        Pokemon p1 = new Pokemon("Чужой", 1);
        Pokemon p2 = new Buzzwole("Жук", 2);
        Pokemon p3 = new Amaura("Динозавр младший", 2);
        Pokemon p4 = new Aurorus("Динозавр старший", 2);
        Pokemon p5 = new Ralts("Гриб", 2);
        Pokemon p6 = new Kirlia("Цветок", 2);
        Pokemon p7 = new Gallade("Растение", 2);
        b.addAlly(p2);
        b.addAlly(p6);
        b.addAlly(p4);
        b.addFoe(p5);
        b.addFoe(p3);
        b.addFoe(p7);
        b.go();
    }
}
