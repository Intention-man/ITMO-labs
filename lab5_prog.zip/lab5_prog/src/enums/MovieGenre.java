package enums;

/**
 *    Enum, containing some movies genre's names
 * */

public enum MovieGenre {
    WESTERN,
    ADVENTURE,
    TRAGEDY;
}
