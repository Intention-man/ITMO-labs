package enums;

/**
 *    Enum, containing some countries names
 * */

public enum Country {
    FRANCE,
    INDIA,
    VATICAN,
    THAILAND,
    SOUTH_KOREA;
}
