package enums;

/**
 *    Enum, containing some movies rating types names
 * */

public enum MpaaRating {
    G,
    PG_13,
    R,
    NC_17;
}
