package enums;

import java.io.Serializable;

/**
 *    Enum, containing some countries names
 * */

public enum Country implements Serializable {
    FRANCE,
    INDIA,
    VATICAN,
    THAILAND,
    SOUTH_KOREA;
}
