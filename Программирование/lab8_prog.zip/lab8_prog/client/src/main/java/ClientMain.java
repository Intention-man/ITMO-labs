import gui.FXApplication;


public class ClientMain {
    public static void main(String[] args) {
        FXApplication.main(args);
    }
}