// Нужно знать: условные операторы, циклы, операции с массивами и библиотеку java.lang.Math
public class Main {
    public static void main(String[] args) {
        int[] k = new int[10];
        for (int i = 6; i < 26; i += 2) {
            k[i / 2 - 3] = i;

        }
        double[] x = new double[13];
        for (int i = 0; i < 13; i++) {
            x[i] = Math.random() * 14 - 2;
        }

        double[][] t = new double[10][];
        for (int i = 0; i < 10; i++) {
            t[i]= new double[13];
            for (int j = 0; j < 13; j++) {
                switch (k[i]) {
                    case 10:
                        t[i][j] = Math.pow(((2.0 / 3) * ((x[j] + (1.0 / 3)) / 3.0 - 0.75)), 0.5 * (Math.tan(Math.cos(x[j]))));
                        break;
                    case 8, 12, 14, 16, 22:
                        t[i][j] = Math.pow((0.75 - x[j]), (x[j] * 0.75 / Math.log10(Math.abs(x[j])))) - 1;
                        break;
                    default:
                        t[i][j] = Math.cos(Math.exp(x[j]) / 3.0);
                        break;
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 13; j++) {
                System.out.printf("%8.5f", t[i][j]);
                System.out.print(" ");
            }
            System.out.println("");
        }
    }
}
