package enums;

import java.io.Serializable;

/**
 *    Enum, containing some movies rating types names
 * */

public enum MpaaRating implements Serializable {
    G,
    PG_13,
    R,
    NC_17;
}
