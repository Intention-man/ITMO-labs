package interfaces;

import classes.MainHero;
import classes.RichPerson;
import enums.ActionsWithPeopleEnum;
import classes.Money;

import java.util.ArrayList;

public interface PerformActionsWithPeopleInterface {

    public void actionWithPeople(RichPerson r, Money m);

    public ArrayList<ActionsWithPeopleEnum> getActions();

    public void addAction(ActionsWithPeopleEnum action);

    public void writeActionOut();

}
