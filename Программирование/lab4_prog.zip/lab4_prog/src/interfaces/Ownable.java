package interfaces;

public interface Ownable {
    boolean isOwn(String name);
    boolean isObey(String name);
}
