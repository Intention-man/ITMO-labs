package interfaces;

import classes.MainHero;

public interface BeGreedy {

    public int levelOfGreed();
    public boolean isGreedPrevailing();
    public void beSkin();
    public void loseWeight();
    public void guzzle(int multiply);
    public void harmHealth(MainHero hero);
}
