package interfaces;

@FunctionalInterface
public interface ToGrowUp {
    String growAlways();
}
