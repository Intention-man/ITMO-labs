package interfaces;

public interface RelationshipWithFertings {
    public void nervous();

    public void reactionToIncrease();

    public void reactionToSpending();

}
