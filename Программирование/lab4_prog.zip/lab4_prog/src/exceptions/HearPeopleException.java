package exceptions;

public class HearPeopleException extends Exception{
    private String speaker;

    public HearPeopleException(String message, String speaker){
        super(message);
        this.speaker = speaker;
    }

    public String getSpeaker(){
        return speaker;
    }
}