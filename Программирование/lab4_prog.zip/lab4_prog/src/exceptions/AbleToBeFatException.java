package exceptions;

public class AbleToBeFatException extends RuntimeException {
    private int levelOfGreed;

    public AbleToBeFatException(String message, int levelOfGreed){
        super(message);
        this.levelOfGreed = levelOfGreed;
    }

    public int getLevelOfGreed(){
        return levelOfGreed;
    }
}
