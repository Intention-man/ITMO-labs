package enums;

public enum ActionsWithMoneyEnum {
    OWN("владеть"),
    USEFORALL("пользоваться деньгами для своих прихотей и удовольствий"),
    SPEND("тратить"),

    OBEY("подчиняться деньгам"),
    TOBEASERVANT("быть у денег покорным слугой"),
    NURTURE("лелеять"),
    CHERISHE("беречь"),
    RAISE("растить свои капиталы");

    private final String str;
    ActionsWithMoneyEnum(String str) {
        this.str = str;
    }
    public String getStr(){
        return this.str;
    }
}
