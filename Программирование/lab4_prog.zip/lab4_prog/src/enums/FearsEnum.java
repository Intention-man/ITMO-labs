package enums;

public enum FearsEnum {
    LOOSINGALLMONEY("Скоро все фертинги, словно под воздействием какой-то злой силы, уплывут из его сундуков и он из богача превратится в нищего"),
    SPENDTOOMUCH("Ему не давала покоя мысль, что он истратил на пищу слишком уж большую сумму денег"),
    DIE("Смерть была для него страшнее всяких потерь денег, деньги ведь не главное!");


    private final String str;

    FearsEnum(String str) {
        this.str = str;
    }
    public String getStr(){
        return this.str;
    }
}