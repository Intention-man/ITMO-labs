package abstract_class;

import classes.MainHero;


import java.util.Objects;

public abstract class RandomPerson extends PeopleAbstract{

    public abstract void mainAction(MainHero hero);

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RandomPerson randomPerson = (RandomPerson) o;
        return Objects.equals(this.getName(), randomPerson.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getName());
    }

    public String toString() {
        return this.getName();
    }

}
