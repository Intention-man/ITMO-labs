package classes;

import abstract_class.RandomPerson;

public class Someone extends RandomPerson {

    private final String name;
    private boolean isSpeak;

    public Someone(String name, boolean isSpeak){
        this.name = name;
        this.isSpeak = isSpeak;
    }

    @Override
    public void mainAction(MainHero hero) {
        System.out.println("Ему почудилось будто " + this.getName() + " что-то сказал.");
    }

    public String getName() {return this.name;}
    public boolean getIsSpeak() {return this.isSpeak;}
}