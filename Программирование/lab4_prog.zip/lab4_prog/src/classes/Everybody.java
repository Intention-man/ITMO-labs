package classes;

import abstract_class.RandomPerson;
import enums.ActionsWithPeopleEnum;

public class Everybody extends RandomPerson {

    private String name;

    public Everybody(String name){
        this.name = name;
    }

    @Override
    public void mainAction(MainHero hero) {
        System.out.print(this.getName() + ", кто видел " + hero.getName() + ", не мог поверить, что перед ним " +
                hero.getStatus() + ", потому что ");
    }

    public String getName() {return this.name;}
}
