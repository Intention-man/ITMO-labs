package classes;

import abstract_class.PeopleAbstract;
import abstract_class.RandomPerson;
import enums.ActionsWithMoneyEnum;
import interfaces.Ownable;

import java.util.ArrayList;
import java.util.Objects;

public class RichPerson extends PeopleAbstract implements Ownable {

    private final ArrayList<ActionsWithMoneyEnum> awme = new ArrayList<>();

    public RichPerson() {
        this.setName("Скуперфильд");
    }

    public RichPerson(String name) {
        this.setName(name);
    }

    public void actionWithMoney(Money money, RandomPerson randomPerson, Society society) {
        if (this.isOwn(money.getName())) {
            continueStory(this.getName());
            this.addAction(ActionsWithMoneyEnum.OWN);
            this.addAction(ActionsWithMoneyEnum.USEFORALL);
            this.write_action_out();
        }
        if (this.isObey(money.getName())) {
            continueStory(this.getName());
            this.addAction(ActionsWithMoneyEnum.OBEY);
            this.addAction(ActionsWithMoneyEnum.TOBEASERVANT);
            this.addAction(ActionsWithMoneyEnum.NURTURE);
            this.addAction(ActionsWithMoneyEnum.CHERISHE);
            this.addAction(ActionsWithMoneyEnum.RAISE);
            this.write_action_out();
        }
    }

    @Override
    public boolean isOwn(String name) {
        return !Objects.equals(this.getName(), "Скуперфильд");
    }

    @Override
    public boolean isObey(String name) {
        return Objects.equals(this.getName(), "Скуперфильд");
    }

    public ArrayList<ActionsWithMoneyEnum> getActions() {
        return awme;
    }

    public void addAction(ActionsWithMoneyEnum action) {
        this.awme.add(action);
    }

    public void write_action_out() {
        StringBuilder awme_str = new StringBuilder();
        for (ActionsWithMoneyEnum action : awme) {
            awme_str.append(action.getStr()).append(", ");
        }
        System.out.println(awme_str.substring(0, awme_str.length() - 2) + ".");
    }

    @Override
    public void continueStory(String s) {
        if (Objects.equals(s, "Скуперфильд")) {
            System.out.print("Если для " + s + " нормальным было ");
        } else {
            System.out.print("Для " + s + " богач(-ей) было свойственно ");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RichPerson that = (RichPerson) o;
        return this.getName().equals(that.getName()) && awme.equals(that.awme);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getName(), awme);
    }

    public String toString() {
        return this.getName();
    }
}
