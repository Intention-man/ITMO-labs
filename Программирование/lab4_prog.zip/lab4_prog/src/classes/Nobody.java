package classes;

import abstract_class.RandomPerson;
import enums.ActionsWithPeopleEnum;
import interfaces.PerformActionsWithPeopleInterface;

import java.util.ArrayList;
import java.util.Objects;

public class Nobody extends RandomPerson implements PerformActionsWithPeopleInterface {
    private final String name;
    ArrayList<ActionsWithPeopleEnum> awpe = new ArrayList<>();

    public Nobody(String name) {
        this.name = name;
    }

    public void mainAction(MainHero hero) {
        System.out.println("непонятно кто не раскрывает своих главных действий вот так вот прямо(");
    }

    @Override
    public void actionWithPeople(RichPerson rich, Money money) {
        if (rich.isObey(money.getName())) {
            this.addAction(ActionsWithPeopleEnum.TAKETOADOCTOR);
            this.addAction(ActionsWithPeopleEnum.TREATASINSANE);
            this.writeActionOut();
        }
    }

    public void isItStrange(MainHero hero, Society society){
        System.out.print("Такое поведение казалось");
        if (Objects.equals(society.getMainValue(), "деньги")) {
            System.out.println(" естественным.");
        } else {
            System.out.println(" странным и неадекватным.");
        }
        society.continueStory(society.getName());
    }

    public void think(MainHero hero, Society society){
        if (Objects.equals(society.getMainValue(), "деньги")){
            System.out.print("И " + this.getName() + " в голову не приходило, что ");
        } else {System.out.print("И " + this.getName() + "всерьез задумывались о том, чтобы ");}
        System.out.print("господина " + hero.getName() + " давно следовало ");
    }

    public ArrayList<ActionsWithPeopleEnum> getActions() {
        return this.awpe;
    }

    public void addAction(ActionsWithPeopleEnum action) {
        this.awpe.add(action);
    }
    public void writeActionOut() {
        StringBuilder awpe_str = new StringBuilder();
        for (ActionsWithPeopleEnum action : this.getActions()) {
            awpe_str.append(action.getStr()).append(" и ");
        }
        System.out.println(awpe_str.substring(0, awpe_str.length() - 2) + "!");
    }

    public String getName() {return this.name;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RandomPerson randomPerson = (RandomPerson) o;
        return Objects.equals(this.getName(), randomPerson.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getName());
    }

    public String toString() {
        return this.getName();
    }
}
