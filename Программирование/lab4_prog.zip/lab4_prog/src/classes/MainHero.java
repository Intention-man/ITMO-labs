package classes;

import enums.FearsEnum;
import exceptions.AbleToBeFatException;
import exceptions.HearPeopleException;
import interfaces.BeGreedy;
import interfaces.RelationshipWithFertings;

public class MainHero extends RichPerson{
    private final String name;
    private String status;

    public MainHero(String name, String status){
        this.name = name;
        this.status = status;
    }

    // Inner Classes
    public class Glasses{
        private final String name;
        private final String owner;
        public Glasses(String name){
            this.name = name;
            this.owner = MainHero.this.name;
        }
        public void beOnNose(){
            System.out.println("Попросив слова, " + MainHero.this.getName() + " нацепил на нос " + this.getName());
        }
        public String getName(){
            return this.name;
        }
    }

    public class Hand{
        private final String name;
        private final String owner;
        public Hand(String name){
            this.name = name;
            this.owner = MainHero.this.name;
        }
        public void rubHead(Head head, Head.Brain brain){
            System.out.println("Он потер " + head.getName() + " с помощью " + this.getName()
                    + ", словно старался разогреть застывшие в " + brain.getName() + " мысли.");
        }
        public void tryToHear(Head.Ear ear, Someone someone, All all, MainHero hero) throws HearPeopleException {
            System.out.println("Он приложил " + this.getName() + " к " + ear.getName() +
                    ", принялся вертеться в разные стороны и заскрипел своим заржавевшим голосом.");
            if (!someone.getIsSpeak()) throw new HearPeopleException(all.sit(), all.getName());
        }

        public String getName(){
            return this.name;
        }
    }

    public class Head {
        private final String name;
        private final String owner;
        public Head(String name){
            this.name = name;
            this.owner = MainHero.this.name;

        }

        public void think(String grow){
            System.out.println("Он почему-то забрал себе в голову, что " + grow);
        }

        public String getName(){
            return this.name;
        }

        //Nested class
        public static class Brain{
            private final String name;
            public Brain(String name){
                this.name = name;
            }
            public String getName(){
                return this.name;
            }
        }

        public static class Ear{
            private final String name;
            public Ear(String name){
                this.name = name;
            }
            public String getName(){
                return this.name;
            }
        }
    }

    //Behavior

    public void behavior(Money fortune, Head head, RelationshipWithFertings r){

        BeGreedy greedBehavior = this.greed();
        greedBehavior.beSkin();
        whyHeSoSkin(greedBehavior);
        System.out.print("Каждый раз, когда приходилось ему истратиь фертинг, ");
        r.nervous();
        greedBehavior.loseWeight();
        System.out.print("Чтобы возместить эти потери, ");
        greedBehavior.guzzle(4);
        try {
            if (canGetFat()){
                System.out.println("И к счастью, набирал вес [правда в теле, а не в обществе]");
            } else {throw new AbleToBeFatException(this.getName() + " слишком жадный", 100);}}
        catch (AbleToBeFatException e) {
            System.out.println(", но все равно не мог потолстеть. ");
            System.out.println(e.getMessage() + ": уровень жадности - " + e.getLevelOfGreed() + " жадин-говядин из 100!");
        }

        fears(1);
        greedBehavior.harmHealth(this);
        head.think(fortune.grow());
        System.out.print("Если ему удавалось увеличить свой капитал хоть на один фертинг, ");
        r.reactionToIncrease();
        System.out.print("Когда же необходимо было истратить фертинг, ");
        r.reactionToSpending();
        fears(2);
    }

    public BeGreedy greed(){
        //local class
        class Sin implements BeGreedy{

            @Override
            public int levelOfGreed() {
                return 100;
            }

            @Override
            public boolean isGreedPrevailing() {
                return true;
            }

            @Override
            public void beSkin() {
                System.out.println("он весь был худой и, если так можно выразиться, узловатый.");
            }

            @Override
            public void loseWeight() {
                System.out.println("что терял в весе.");
            }

            @Override
            public void guzzle(int multiply) {
                System.out.print("он съедал ежедневно по " + multiply + " завтрака, обеда и ужина");
            }

            @Override
            public void harmHealth(MainHero hero) {
                System.out.println("Господин " + hero.getName() + " прекрасно знал, что его жадность вредит его же здоровью, но со своей собачьей натурой (так он говорил сам) ничего поделать не мог.");
            }
        }
        return new Sin();
    }

    public void actionWithFertings(Money fortune, Head head){
        // anonymous class
        behavior(fortune, head, new RelationshipWithFertings() {
            @Override
            public void nervous() {
                System.out.print("он так нервничал, так терзался от жадности,");
            }

            @Override
            public void reactionToIncrease() {
                System.out.println("он готов был прыгать от радости;");
            }

            @Override
            public void reactionToSpending() {
                System.out.println("он приходил в отчаяние.");
            }
        });
    }

    // getters and setters

    public String getName(){
        return this.name;
    }
    public String getStatus(){
        return this.status;
    }

    public void setStatus(String status){
        this.status = status;
    }

    // others
    public void whyHeSoSkin(BeGreedy greedBehavior){
        if (greedBehavior.isGreedPrevailing()) {
            System.out.println("Однако был он таким потому, что был жаден... Очень!");
        } else {
            System.out.println("Кушать было нечего, вот в чем дело!");
        }
    }
    public void fears(int number){
        switch (number) {
            case 1 -> System.out.println(FearsEnum.SPENDTOOMUCH.getStr());
            case 2 -> System.out.println(FearsEnum.LOOSINGALLMONEY.getStr());
            default -> System.out.println(FearsEnum.DIE.getStr());
        }
    }
    public boolean canGetFat() throws AbleToBeFatException {
        BeGreedy greedBehavior = this.greed();
        return (greedBehavior.levelOfGreed() < 75);
    }
}