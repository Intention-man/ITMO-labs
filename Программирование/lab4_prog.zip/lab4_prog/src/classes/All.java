package classes;

import abstract_class.RandomPerson;
import enums.ActionsWithPeopleEnum;

public class All extends RandomPerson {
    private final String name;

    public All(String name){
        this.name = name;
    }

    @Override
    public void mainAction(MainHero hero) {
        System.out.println("Стоят и болтают");;
    }

    public String sit(){
        return "Убедившись в том, что " + this.getName() + " сидят молча, ";
    }

    public String getName() {return this.name;}
}
