import classes.*;
import exceptions.HearPeopleException;

public class Main {
    public static void main(String[] args){

        // INITIALIZATION

        MainHero scuperfild = new MainHero("Скуперфильд", "миллионер");
        MainHero.Glasses glasses = scuperfild.new Glasses("Очки");
        MainHero.Hand leftHand = scuperfild.new Hand("Левая рука"),
                rightHand = scuperfild.new Hand("Правая рука");
        MainHero.Head head = scuperfild.new Head("Голова");
        MainHero.Head.Brain brain = new MainHero.Head.Brain("Мозг");
        MainHero.Head.Ear ear = new MainHero.Head.Ear ("Ухо");
        Society society = new Society();
        Nobody nobody = new Nobody("Никто");
        Everybody everybody = new Everybody("Каждый");
        All all = new All("Все");
        Someone someone = new Someone("Кто-то", false);
        Money money = new Money("Деньги");
        Money fortune = new Money("Состояние");
        RichPerson others = new RichPerson("Другие");

        // ACTIONS

        // usual cases
        everybody.mainAction(scuperfild);
        scuperfild.actionWithFertings(fortune, head);

        // compare with other riches
        money.actionWithPeople(others, money);
        others.actionWithMoney(money, nobody, society);
        money.actionWithPeople(scuperfild, money);
        scuperfild.actionWithMoney(money, nobody, society);
        nobody.isItStrange(scuperfild, society);
        nobody.think(scuperfild, society);
        nobody.actionWithPeople((RichPerson) scuperfild, money);

        //incident in society

        glasses.beOnNose();
        leftHand.rubHead(head, brain);
        someone.mainAction(scuperfild);

        try {
            rightHand.tryToHear(ear, someone, all, scuperfild);
        } catch (Exception e){
            System.out.print(e.getMessage());
        } finally {
            System.out.println(scuperfild + " успокоился и сказал:");
        }
    }
}