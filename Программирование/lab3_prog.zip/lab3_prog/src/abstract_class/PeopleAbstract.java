package abstract_class;


import interfaces.HeroesOfStoryInterface;


public abstract class PeopleAbstract<T> implements HeroesOfStoryInterface {

    private String name;
    public PeopleAbstract(){}

    public String getName() {return this.name;}

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void continueStory(String s) {}
}
