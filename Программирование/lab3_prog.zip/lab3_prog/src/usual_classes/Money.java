package usual_classes;

import enums.ActionsWithPeopleEnum;
import interfaces.ActionsWithPeopleInterface;
import interfaces.HeroesOfStoryInterface;
import interfaces.OwnInterface;

import java.util.ArrayList;
import java.util.Objects;

public class Money implements OwnInterface, HeroesOfStoryInterface, ActionsWithPeopleInterface {

    private String name;
    ArrayList<ActionsWithPeopleEnum> awpe = new ArrayList<>();
    public Money(){
        this.setName("Деньги");
    }

    public void actionWithPeople(RichPerson rich, Money money) {
        if (this.isOwn(rich.getName())) {
            this.addAction(ActionsWithPeopleEnum.OWN);
            continueStory(rich.getName());
            this.writeActionOut();
        }
    }

    public ArrayList<ActionsWithPeopleEnum> getActions() {
        return this.awpe;
    }

    public void addAction(ActionsWithPeopleEnum action) {
        this.awpe.add(action);
    }

    public void writeActionOut() {
        StringBuilder awpe_str = new StringBuilder();
        for (ActionsWithPeopleEnum action : this.getActions()) {
            awpe_str.append(action.getStr()).append(", ");
        }
        System.out.println(awpe_str.substring(0, awpe_str.length() - 2) + ".");
    }

    @Override
    public boolean isOwn(String name) {
        return Objects.equals(name, "Скуперфильд");}

    @Override
    public boolean isObey(String name) {
        return !Objects.equals(name, "Скуперфильд");
    }

    @Override
    public void continueStory(String name) {
        System.out.print("То в отношении " + name + " можно было сказать, что " + this.getName() + " полностью ");

    }

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Money money = (Money) o;
        return Objects.equals(name, money.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public String toString() {
        return name;
    }
}