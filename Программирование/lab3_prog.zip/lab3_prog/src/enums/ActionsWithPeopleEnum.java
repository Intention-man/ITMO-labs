package enums;

public enum ActionsWithPeopleEnum {
    OWN("владели им"),
    OBEY("подчиняться"),
    TAKETOADOCTOR("отвести к врачу"),
    TREATASINSANE("лечить с той же заботливостью, с какой лечат каждого повредившегося в уме");

    private final String str;

    ActionsWithPeopleEnum(String str) {
        this.str = str;
    }
    public String getStr(){
        return this.str;
    }
}
