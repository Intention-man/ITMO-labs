package interfaces;


@FunctionalInterface
public interface HeroesOfStoryInterface {
    public void continueStory(String s);
}