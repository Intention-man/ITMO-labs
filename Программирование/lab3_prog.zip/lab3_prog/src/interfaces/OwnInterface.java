package interfaces;

import usual_classes.Society;
import usual_classes.Somebody;

public interface OwnInterface {
    boolean isOwn(String name);
    boolean isObey(String name);
}
