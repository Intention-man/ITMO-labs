package interfaces;

import enums.ActionsWithPeopleEnum;
import usual_classes.Money;
import usual_classes.RichPerson;

public interface ActionsWithPeopleInterface {

    public void actionWithPeople(RichPerson rich, Money m);

    public void addAction(ActionsWithPeopleEnum action);

    public void writeActionOut();
}
